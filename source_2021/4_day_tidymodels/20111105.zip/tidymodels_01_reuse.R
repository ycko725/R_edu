# ---- tidymodels ----

library(tidymodels)
data("iris")

# 데이터 분리

# 교차검증 데이터셋 준비


# ---- Use default parameters in parsnip ---- 
# randomForest


# Create Model 


# Fit Traning Data


# 예측 평가


# 혼동 행렬


# 다양한 모델 평가지표 




# ---- Use tune to tune parsnip model ----
# 파라미터 추가
# 옵션 1


# 옵션 2


# Create Workflow


# ---- Grid Search ----


# ---- show best model ----


# ---- Random Search ----


